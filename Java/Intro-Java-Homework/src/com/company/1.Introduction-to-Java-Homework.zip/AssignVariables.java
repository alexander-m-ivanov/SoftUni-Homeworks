package com.company;

public class AssignVariables {

    public static void main(String[] args) {
        byte a = 127;
        short b = 3276;
        short j = 32767;
        int c = 2000000000;
        long d = 919827112351L;
        char e = 'c';
        boolean f = false;
        float g = 0.5f;
        double h = 0.1234567891011;
        String i = "Palo Alto, CA";

        System.out.printf ("Byte a is: %d%n", a);
        System.out.printf ("Short b is: %d%n", b);
        System.out.printf ("Short j is: %d%n", j);
        System.out.printf ("Int c is: %d%n", c);
        System.out.printf ("Long d is: %d%n", d);
        System.out.println ("Char e is: " + e);
        System.out.println ("Float g is: " + f);
        System.out.printf ("float g is: %f%n", g);
        System.out.printf ("Double h is: %f%n", h);
        System.out.println ("String i is: " + i);
    }
}




